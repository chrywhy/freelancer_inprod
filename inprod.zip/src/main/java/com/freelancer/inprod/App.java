/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.freelancer.inprod;
import com.freelancer.inprod.sql.DbUtil;

/**
 *
 * @author Albert Wang
 */
public class App {
    public static void main(String args[]) {
        String host = args[0];
        int port = Integer.parseInt(args[1]);
        String username = args[2];
        String password = args.length >= 4 ? args[3] : "";        
        DbUtil.initConnectionPool(host, port, username, password);
        
        InProd inProd = new InProd();
        inProd.generateTables();
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.freelancer.inprod.pojo.db;

/**
 *
 * @author chry
 */
class QueryReqource {
    
}
